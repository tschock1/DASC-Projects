﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace $safeprojectname$
{
    public partial class Rentals : Form
    {
        public Rentals()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            // Create an instance of the MainMenu form
            MainMenu mainMenu = new MainMenu();
            // Show the MainMenu form
            mainMenu.Show();
            // Hide the current login form
            this.Hide();
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Rentals_Load(object sender, EventArgs e)
        {
            DataTable dtRentals = new DataTable();
            try
            {
                string query = @"
            SELECT 
                r.rental_id,
                r.rent_date,
                r.employee_id,
                r.vendor_id,
                m.media_title
            FROM dbo.rental r
            LEFT JOIN dbo.media m ON r.media_id = m.media_id
            ORDER BY r.rental_id";

                Walton_DB.FillDataTable_ViaSql(ref dtRentals, query);

                if (dtRentals == null)
                {
                    MessageBox.Show("DataTable is null. Check FillDataTable_ViaSql method or database connection.");
                    return;
                }

                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = dtRentals;

                // Customize column headers with safety checks
                if (dataGridView1.Columns.Contains("rental_id"))
                {
                    dataGridView1.Columns["rental_id"].HeaderText = "Rental ID";
                    dataGridView1.Columns["rental_id"].DisplayIndex = 0;
                }
                if (dataGridView1.Columns.Contains("rent_date"))
                {
                    dataGridView1.Columns["rent_date"].HeaderText = "Rental Date";
                    dataGridView1.Columns["rent_date"].DisplayIndex = 1;
                }
                if (dataGridView1.Columns.Contains("media_title"))
                {
                    dataGridView1.Columns["media_title"].HeaderText = "Media Title";
                    dataGridView1.Columns["media_title"].DisplayIndex = 2;
                }
                if (dataGridView1.Columns.Contains("employee_id"))
                {
                    dataGridView1.Columns["employee_id"].HeaderText = "Employee ID";
                    dataGridView1.Columns["employee_id"].DisplayIndex = 3;
                }
                if (dataGridView1.Columns.Contains("vendor_id"))
                {
                    dataGridView1.Columns["vendor_id"].HeaderText = "Vendor ID";
                    dataGridView1.Columns["vendor_id"].DisplayIndex = 4;
                }

                dataGridView1.Refresh();

                if (dtRentals.Rows.Count == 0)
                {
                    MessageBox.Show("No rental records found. Add rentals to the database to display them.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading rentals: {ex.Message}");
            }
        }

        private void txtRentalDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddRental_Click(object sender, EventArgs e)
        {
            if (txtRentalDate.Text.Trim() == "" || txtMediaTitle.Text.Trim() == "")
            {
                MessageBox.Show("You must enter both a rental date and a media title.");
            }
            else
            {
                bool QuerySuccessful = false;

                // Step 1: Validate and parse the rental date
                DateTime rentalDate;
                if (!DateTime.TryParse(txtRentalDate.Text, out rentalDate))
                {
                    MessageBox.Show("Invalid rental date format. Please use a valid date (e.g., 3/31/2025).");
                    return;
                }

                // Step 2: Look up the media_id based on the media_title using FillDataTable_ViaSQL
                // Note: This approach is vulnerable to SQL injection. Ideally, use a parameterized method.
                string sqlQuery = "SELECT media_id FROM dbo.media WHERE media_title = '" + txtMediaTitle.Text.Trim().Replace("'", "''") + "'";
                DataTable dt = new DataTable();
                Walton_DB.FillDataTable_ViaSql(ref dt, sqlQuery);

                // Check if the media title exists
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("The media title '" + txtMediaTitle.Text + "' was not found in the database.");
                    return;
                }

                // Get the media_id from the first row
                int mediaId = Convert.ToInt32(dt.Rows[0]["media_id"]);

                // Step 3: Insert the rental into dbo.rental
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT INTO dbo.rental (rent_date, media_id) VALUES (@rentalDate, @mediaId)";
                cmd.Parameters.Add("@rentalDate", SqlDbType.DateTime).Value = rentalDate;
                cmd.Parameters.Add("@mediaId", SqlDbType.Int).Value = mediaId;

                // Add try-catch to capture detailed error
                try
                {
                    QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error inserting rental: " + ex.Message);
                    return;
                }

                if (QuerySuccessful)
                {
                    // Rental successfully added, notify user and clear textboxes
                    MessageBox.Show("The rental for " + txtMediaTitle.Text + " on " + rentalDate.ToString("d") +
                        " was successfully added to the database.");
                    txtRentalDate.Text = "";
                    txtMediaTitle.Text = "";

                    // Refresh the grid
                    DataTable dtRental = new DataTable();
                    sqlQuery = "SELECT r.rental_id, r.rent_date, m.media_title " +
                               "FROM dbo.rental r " +
                               "JOIN dbo.media m ON r.media_id = m.media_id";
                    Walton_DB.FillDataTable_ViaSql(ref dtRental, sqlQuery);
                    if (dtRental == null)
                    {
                        MessageBox.Show("DataTable is null. Check FillDataTable_ViaSQL method or database connection.");
                        return;
                    }
                    dataGridView1.DataSource = dtRental; // Assuming dataGridViewRentals is your grid
                }
                else
                {
                    // Error occurred, notify user, do not clear textboxes
                    MessageBox.Show("An error occurred while adding the rental for " + txtMediaTitle.Text + ".");
                }
            }
        }
    }
}