using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Using SQL Command & Parameters to prevent SQL Injection
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT employee_id from dbo.employee Where employee_id = @Name and Password = @Password";
            cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = txtUserLogin.Text;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 50).Value = txtPassword.Text;

            DataTable dt = null;

            if (Walton_DB.FillDataTable_ViaCmd(ref dt, ref cmd))
            {   // If row count > 0, then they entered a valid username and password
                if (dt != null && dt.Rows.Count > 0)
                {
                    MessageBox.Show("Login Success");
                    // Code here to open Next Screen
                    // Create an instance of the MainMenu form
                    MainMenu mainMenu = new MainMenu();

                    // Show the MainMenu form
                    mainMenu.Show();

                    // Hide the current login form
                    this.Hide();
                }
                else
                {   // Rows returned = 0, then nothing matches username password
                    MessageBox.Show("Password Incorrect - Login Failed!");
                }
            }
            else
            {
                MessageBox.Show("Database / Network Error - Login Failed");
            }


        }

        private void txtUserLogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
