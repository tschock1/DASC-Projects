﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class Employees : Form
    {
        public Employees()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the MainMenu form
            MainMenu mainMenu = new MainMenu();

            // Show the MainMenu form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Employees_Load(object sender, EventArgs e)
        {
            DataTable dtEmployees = null;
            Walton_DB.FillDataTable_ViaSql(ref dtEmployees, "SELECT * FROM dbo.employee ORDER BY employee_id");

            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
            {
                dataGridView1.DataSource = dtEmployees;
                dataGridView1.Refresh();
            }
        }

        private void btnAddTitle_Click(object sender, EventArgs e)
        {
            // Assuming txtName is the title textbox and txtType is the type textbox
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("You must enter a name.");
            }
            else
            {
                bool QuerySuccessful = false;

                // Build SQL Command and use SQL Parameters to prevent SQL Injection
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT INTO dbo.employee (first_name, last_name) VALUES (@name, @type)";
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 255).Value = txtName.Text;
                // If type is optional, use DBNull.Value if txtType is empty
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 50).Value =
                    txtType.Text.Trim() == "" ? DBNull.Value : txtType.Text;

                QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                if (QuerySuccessful)
                {
                    // Name and type successfully added, notify user and clear textboxes
                    MessageBox.Show("The employee " + txtName.Text + " " +
                        (txtType.Text.Trim() == "" ? "not specified" : txtType.Text) +
                        " was successfully added to the database.");
                    txtName.Text = "";
                    txtType.Text = "";
                }
                else
                {
                    // Error occurred, notify user, do not clear textboxes
                    MessageBox.Show("An error occurred while adding the employee " + txtName.Text + " to the database.");
                }
            }
        }
    }
}
