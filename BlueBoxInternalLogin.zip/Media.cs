﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Media : Form
    {
        private DataTable mediaDataTable; // To track the data source and detect new rows

        public Media()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            // Create an instance of the MainMenu form
            MainMenu mainMenu = new MainMenu();

            // Show the MainMenu form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void Media_Load(object sender, EventArgs e)
        {
            // Load the data into the DataGridView
            mediaDataTable = new DataTable();
            Walton_DB.FillDataTable_ViaSql(ref mediaDataTable, "SELECT * FROM dbo.media ORDER BY media_id");

            if (mediaDataTable != null)
            {
                dataGridView1.DataSource = mediaDataTable;
                dataGridView1.Refresh();

                // Enable editing and adding new rows
                dataGridView1.ReadOnly = false;
                dataGridView1.AllowUserToAddRows = true;
                if (dataGridView1.Columns["media_id"] != null)
                {
                    dataGridView1.Columns["media_id"].ReadOnly = true; // Prevent editing the media_id
                }
            }
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                if (row.IsNewRow) return; // Skip the new row placeholder

                DataRowView rowView = row.DataBoundItem as DataRowView;
                if (rowView == null) return;

                DataRow dataRow = rowView.Row;

                // Check if the row is new (added by the user) or existing (being edited)
                if (dataRow.RowState == DataRowState.Added)
                {
                    // Get the next media_id
                    DataTable dtMaxId = new DataTable();
                    Walton_DB.FillDataTable_ViaSql(ref dtMaxId, "SELECT MAX(media_id) AS MaxId FROM dbo.media");
                    int nextMediaId = 2000; // Default starting value if table is empty
                    if (dtMaxId != null && dtMaxId.Rows.Count > 0 && dtMaxId.Rows[0]["MaxId"] != DBNull.Value)
                    {
                        nextMediaId = Convert.ToInt32(dtMaxId.Rows[0]["MaxId"]) + 1;
                    }

                    // This is a new row, so insert it into the database
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "INSERT INTO dbo.media (media_id, media_title, type) VALUES (@MediaId, @MediaTitle, @MediaType)";
                    cmd.Parameters.Add("@MediaId", SqlDbType.Int).Value = nextMediaId;
                    cmd.Parameters.Add("@MediaTitle", SqlDbType.NVarChar, 255).Value = dataRow["media_title"] != DBNull.Value ? dataRow["media_title"] : DBNull.Value;
                    cmd.Parameters.Add("@MediaType", SqlDbType.NVarChar, 50).Value = dataRow["type"] != DBNull.Value ? dataRow["type"] : DBNull.Value;

                    bool querySuccessful = false;
                    try
                    {
                        querySuccessful = Walton_DB.ExecSqlCommand(ref cmd);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error inserting new media record: " + ex.Message);
                        return;
                    }

                    if (querySuccessful)
                    {
                        MessageBox.Show("New media record added successfully.");
                        // Reload the DataGridView to reflect the new row
                        mediaDataTable = new DataTable();
                        Walton_DB.FillDataTable_ViaSql(ref mediaDataTable, "SELECT * FROM dbo.media ORDER BY media_id");
                        dataGridView1.DataSource = mediaDataTable;
                        dataGridView1.Refresh();
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert new media record. Check database constraints or connection.");
                        // Remove the row from the DataGridView to revert the change
                        dataRow.Delete();
                    }
                }
                else if (dataRow.RowState == DataRowState.Modified)
                {
                    // This is an existing row that was edited, so update the database
                    int mediaId = Convert.ToInt32(dataRow["media_id"]);
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "UPDATE dbo.media SET media_title = @MediaTitle, type = @MediaType WHERE media_id = @MediaId";
                    cmd.Parameters.Add("@MediaTitle", SqlDbType.NVarChar, 255).Value = dataRow["media_title"] != DBNull.Value ? dataRow["media_title"] : DBNull.Value;
                    cmd.Parameters.Add("@MediaType", SqlDbType.NVarChar, 50).Value = dataRow["type"] != DBNull.Value ? dataRow["type"] : DBNull.Value;
                    cmd.Parameters.Add("@MediaId", SqlDbType.Int).Value = mediaId;

                    bool querySuccessful = false;
                    try
                    {
                        querySuccessful = Walton_DB.ExecSqlCommand(ref cmd);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating media record: " + ex.Message);
                        return;
                    }

                    if (querySuccessful)
                    {
                        MessageBox.Show("Media record updated successfully for media_id " + mediaId + ".");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update media record for media_id " + mediaId + ". Check database constraints or connection.");
                        // Reload the DataGridView to revert the change
                        mediaDataTable = new DataTable();
                        Walton_DB.FillDataTable_ViaSql(ref mediaDataTable, "SELECT * FROM dbo.media ORDER BY media_id");
                        dataGridView1.DataSource = mediaDataTable;
                        dataGridView1.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes to database: " + ex.Message);
                // Reload the DataGridView to revert any changes
                mediaDataTable = new DataTable();
                Walton_DB.FillDataTable_ViaSql(ref mediaDataTable, "SELECT * FROM dbo.media ORDER BY media_id");
                dataGridView1.DataSource = mediaDataTable;
                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnAddTitle_Click(object sender, EventArgs e)
        {
            // Assuming txtName is the title textbox and txtType is the type textbox
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("You must enter a title.");
            }
            else
            {
                bool QuerySuccessful = false;

                // Build SQL Command and use SQL Parameters to prevent SQL Injection
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT INTO dbo.media (media_title, type) VALUES (@name, @type)";
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 255).Value = txtName.Text;
                // If type is optional, use DBNull.Value if txtType is empty
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 50).Value =
                    txtType.Text.Trim() == "" ? DBNull.Value : txtType.Text;

                QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                if (QuerySuccessful)
                {
                    // Name and type successfully added, notify user and clear textboxes
                    MessageBox.Show("The title " + txtName.Text + " with type " +
                        (txtType.Text.Trim() == "" ? "not specified" : txtType.Text) +
                        " was successfully added to the database.");
                    txtName.Text = "";
                    txtType.Text = "";
                }
                else
                {
                    // Error occurred, notify user, do not clear textboxes
                    MessageBox.Show("An error occurred while adding the title " + txtName.Text + " to the database.");
                }
            }
        }

        private void btnRemoveTitle_Click(object sender, EventArgs e)
        {
            {
                // Check if something has been entered into the textbox
                if (txtName.Text.Trim() == "")
                {
                    MessageBox.Show("You must enter a title.");
                }
                else
                {
                    bool QuerySuccessful = false;

                    // Build SQL Command and use SQL Paramters to prevent SQL Injection

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "DELETE FROM dbo.media WHERE media_title = @name";
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = txtName.Text;
                    QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                    if (QuerySuccessful)
                    {
                        // Name successfully entered, notify user and clear textbox
                        MessageBox.Show("The title " + txtName.Text + " was successfully removed from the database.");
                        txtName.Text = "";
                    }
                    else
                    {
                        // Error occurred, notify user, do not clear textbox
                        MessageBox.Show("An error occurred while removing the title " + txtName.Text + " from the database.");
                    }

                }
            }
        }

        private void btnAddType_Click(object sender, EventArgs e)
        {
            {
                // Check if something has been entered into the textbox
                if (txtType.Text.Trim() == "")
                {
                    MessageBox.Show("You must enter a type.");
                }
                else
                {
                    bool QuerySuccessful = false;

                    // Build SQL Command and use SQL Paramters to prevent SQL Injection

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "INSERT INTO dbo.media(type) VALUES (@Name)";
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = txtType.Text;
                    QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                    if (QuerySuccessful)
                    {
                        // Name successfully entered, notify user and clear textbox
                        MessageBox.Show("The media type " + txtType.Text + " was successfully added to the database.");
                        txtName.Text = "";
                    }
                    else
                    {
                        // Error occurred, notify user, do not clear textbox
                        MessageBox.Show("An error occurred while entering the media type " + txtType.Text + " into the database.");
                    }

                }
            }
        }

        private void btnRemoveType_Click(object sender, EventArgs e)
        {
            // Check if something has been entered into the textbox
            if (txtType.Text.Trim() == "")
            {
                MessageBox.Show("You must enter a type.");
            }
            else
            {
                bool QuerySuccessful = false;

                // Build SQL Command and use SQL Paramters to prevent SQL Injection

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT INTO dbo.media(type) VALUES (@Name)";
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = txtType.Text;
                QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                if (QuerySuccessful)
                {
                    // Name successfully entered, notify user and clear textbox
                    MessageBox.Show("The media type " + txtType.Text + " was successfully added to the database.");
                    txtName.Text = "";
                }
                else
                {
                    // Error occurred, notify user, do not clear textbox
                    MessageBox.Show("An error occurred while entering the media type " + txtType.Text + " into the database.");
                }

            }
        }
    }
}