﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            txtUserLogin = new TextBox();
            btnLogin = new Button();
            lblPassword = new Label();
            txtPassword = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            lblBluebox = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Cyan;
            label1.Location = new Point(58, 58);
            label1.Name = "label1";
            label1.Size = new Size(116, 17);
            label1.TabIndex = 0;
            label1.Text = "Employee ID:";
            label1.Click += label1_Click;
            // 
            // txtUserLogin
            // 
            txtUserLogin.BackColor = Color.Gray;
            txtUserLogin.BorderStyle = BorderStyle.None;
            txtUserLogin.Font = new Font("Courier New", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUserLogin.ForeColor = Color.Cyan;
            txtUserLogin.Location = new Point(180, 61);
            txtUserLogin.Name = "txtUserLogin";
            txtUserLogin.Size = new Size(100, 14);
            txtUserLogin.TabIndex = 1;
            txtUserLogin.TextChanged += txtUserLogin_TextChanged;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.Gray;
            btnLogin.Cursor = Cursors.Default;
            btnLogin.FlatAppearance.BorderColor = Color.Black;
            btnLogin.Font = new Font("Courier New", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = Color.Cyan;
            btnLogin.Location = new Point(180, 130);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(100, 27);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += button1_Click;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Courier New", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = Color.Cyan;
            lblPassword.Location = new Point(85, 94);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(89, 17);
            lblPassword.TabIndex = 3;
            lblPassword.Text = "Password:";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.Gray;
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("Courier New", 9F);
            txtPassword.ForeColor = Color.Cyan;
            txtPassword.Location = new Point(180, 97);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(100, 14);
            txtPassword.TabIndex = 4;
            txtPassword.TextChanged += txtPassword_TextChanged;
            // 
            // timer1
            // 
            timer1.Interval = 500;
            // 
            // lblBluebox
            // 
            lblBluebox.AutoSize = true;
            lblBluebox.Font = new Font("Courier New", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBluebox.ForeColor = Color.Cyan;
            lblBluebox.Location = new Point(124, 18);
            lblBluebox.Name = "lblBluebox";
            lblBluebox.Size = new Size(205, 23);
            lblBluebox.TabIndex = 5;
            lblBluebox.Text = "BlueBox Rentals";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowText;
            ClientSize = new Size(404, 178);
            Controls.Add(lblBluebox);
            Controls.Add(txtPassword);
            Controls.Add(lblPassword);
            Controls.Add(btnLogin);
            Controls.Add(txtUserLogin);
            Controls.Add(label1);
            Cursor = Cursors.IBeam;
            ForeColor = Color.Cyan;
            Name = "Form1";
            Text = "Login";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtUserLogin;
        private Button btnLogin;
        private Label lblPassword;
        private TextBox txtPassword;
        private System.Windows.Forms.Timer timer1;
        private Label lblBluebox;
    }
}
