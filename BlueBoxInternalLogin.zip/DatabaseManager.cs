﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient; // Using Microsoft.Data.SqlClient instead


namespace $safeprojectname$
{
    internal class DatabaseManager
    {
        private static string connectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=DASC_Spring2025_Shipp_TeamEcho;User ID=db_Login;Password=DbPass_SpPs65BD";

        public static Microsoft.Data.SqlClient.SqlConnection GetConnection()
        {
            return new Microsoft.Data.SqlClient.SqlConnection(connectionString);
        }

        public static DataTable ExecuteQuery(string query)
        {
            DataTable dataTable = new DataTable();
            using (Microsoft.Data.SqlClient.SqlConnection conn = GetConnection())
            {
                conn.Open();
                Microsoft.Data.SqlClient.SqlDataAdapter adapter = new Microsoft.Data.SqlClient.SqlDataAdapter(query, conn);
                adapter.Fill(dataTable);
            }
            return dataTable;
        }
    }
}
