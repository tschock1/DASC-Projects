﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Create an instance of the Vendors form
            Vendors mainMenu = new Vendors();

            // Show the Vendors form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the Rentals form
            Rentals mainMenu = new Rentals();

            // Show the Rentals form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create an instance of the Employees form
            Employees mainMenu = new Employees();

            // Show the Employees form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Create an instance of the Media form
            Media mainMenu = new Media();

            // Show the Media form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Create an instance of the Form1 (login form)
            Form1 loginForm = new Form1();

            // Show the login form
            loginForm.Show();

            // Close the current main menu form
            this.Close();

        }
    }
}
