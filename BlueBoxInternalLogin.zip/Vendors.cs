﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class Vendors : Form
    {
        public Vendors()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            // Create an instance of the MainMenu form
            MainMenu mainMenu = new MainMenu();

            // Show the MainMenu form
            mainMenu.Show();

            // Hide the current login form
            this.Hide();
        }

        private void Vendors_Load(object sender, EventArgs e)
        {
            DataTable dtVendors = null;
            Walton_DB.FillDataTable_ViaSql(ref dtVendors, "SELECT * FROM dbo.vendor ORDER BY vendor_id");

            if (dtVendors != null && dtVendors.Rows.Count > 0)
            {
                dataGridView1.DataSource = dtVendors;
                dataGridView1.Refresh();
            }
        }

        private void btnAddTitle_Click(object sender, EventArgs e)
        {
            // Check if something has been entered into the textbox
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("You must enter a vendor.");
            }
            else
            {
                bool QuerySuccessful = false;

                // Build SQL Command and use SQL Paramters to prevent SQL Injection

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT INTO dbo.vendor(origin) VALUES (@Name)";
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = txtName.Text;
                QuerySuccessful = Walton_DB.ExecSqlCommand(ref cmd);

                if (QuerySuccessful)
                {
                    // Name successfully entered, notify user and clear textbox
                    MessageBox.Show("The vendor " + txtName.Text + " was successfully added to the database.");
                    txtName.Text = "";
                }
                else
                {
                    // Error occurred, notify user, do not clear textbox
                    MessageBox.Show("An error occurred while entering the vendor " + txtName.Text + " into the database.");
                }

            }
        }
    }
}
