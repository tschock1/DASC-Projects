﻿namespace $safeprojectname$
{
    partial class Rentals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Back = new Button();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            txtRentalDate = new TextBox();
            label3 = new Label();
            txtMediaTitle = new TextBox();
            btnAddRental = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Cyan;
            label1.Location = new Point(249, 26);
            label1.Name = "label1";
            label1.Size = new Size(248, 39);
            label1.TabIndex = 0;
            label1.Text = "Rental Data";
            // 
            // Back
            // 
            Back.BackColor = Color.Gray;
            Back.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Back.ForeColor = Color.Cyan;
            Back.Location = new Point(12, 402);
            Back.Name = "Back";
            Back.Size = new Size(105, 36);
            Back.TabIndex = 1;
            Back.Text = "Back";
            Back.UseVisualStyleBackColor = false;
            Back.Click += Back_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(88, 81);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(371, 271);
            dataGridView1.TabIndex = 2;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Courier New", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Cyan;
            label2.Location = new Point(493, 92);
            label2.Name = "label2";
            label2.Size = new Size(264, 27);
            label2.TabIndex = 7;
            label2.Text = "Input Rental Date:";
            // 
            // txtRentalDate
            // 
            txtRentalDate.BackColor = Color.Gray;
            txtRentalDate.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtRentalDate.ForeColor = Color.Cyan;
            txtRentalDate.Location = new Point(493, 139);
            txtRentalDate.Name = "txtRentalDate";
            txtRentalDate.Size = new Size(261, 26);
            txtRentalDate.TabIndex = 8;
            txtRentalDate.TextChanged += txtRentalDate_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Courier New", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Cyan;
            label3.Location = new Point(493, 189);
            label3.Name = "label3";
            label3.Size = new Size(264, 27);
            label3.TabIndex = 9;
            label3.Text = "Input Media Title:";
            // 
            // txtMediaTitle
            // 
            txtMediaTitle.BackColor = Color.Gray;
            txtMediaTitle.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMediaTitle.ForeColor = Color.Cyan;
            txtMediaTitle.Location = new Point(493, 232);
            txtMediaTitle.Name = "txtMediaTitle";
            txtMediaTitle.Size = new Size(261, 26);
            txtMediaTitle.TabIndex = 10;
            // 
            // btnAddRental
            // 
            btnAddRental.BackColor = Color.Gray;
            btnAddRental.Font = new Font("Courier New", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddRental.ForeColor = Color.Cyan;
            btnAddRental.Location = new Point(493, 284);
            btnAddRental.Name = "btnAddRental";
            btnAddRental.Size = new Size(261, 68);
            btnAddRental.TabIndex = 11;
            btnAddRental.Text = "Add Rental";
            btnAddRental.UseVisualStyleBackColor = false;
            btnAddRental.Click += btnAddRental_Click;
            // 
            // Rentals
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAddRental);
            Controls.Add(txtMediaTitle);
            Controls.Add(label3);
            Controls.Add(txtRentalDate);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(Back);
            Controls.Add(label1);
            Name = "Rentals";
            Load += Rentals_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button Back;
        private DataGridView dataGridView1;
        private Label label2;
        private TextBox txtRentalDate;
        private Label label3;
        private TextBox txtMediaTitle;
        private Button btnAddRental;
    }
}