﻿namespace $safeprojectname$
{
    partial class Vendors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Back = new Button();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            txtName = new TextBox();
            btnAddTitle = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Cyan;
            label1.Location = new Point(250, 29);
            label1.Name = "label1";
            label1.Size = new Size(248, 39);
            label1.TabIndex = 0;
            label1.Text = "Vendor Data";
            // 
            // Back
            // 
            Back.BackColor = Color.Gray;
            Back.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Back.ForeColor = Color.Cyan;
            Back.Location = new Point(12, 402);
            Back.Name = "Back";
            Back.Size = new Size(105, 36);
            Back.TabIndex = 3;
            Back.Text = "Back";
            Back.UseVisualStyleBackColor = false;
            Back.Click += Back_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(90, 81);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(373, 282);
            dataGridView1.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Courier New", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Cyan;
            label2.Location = new Point(517, 81);
            label2.Name = "label2";
            label2.Size = new Size(194, 27);
            label2.TabIndex = 7;
            label2.Text = "Input Vendor:";
            // 
            // txtName
            // 
            txtName.BackColor = Color.Gray;
            txtName.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.ForeColor = Color.Cyan;
            txtName.Location = new Point(487, 133);
            txtName.Name = "txtName";
            txtName.Size = new Size(261, 26);
            txtName.TabIndex = 8;
            // 
            // btnAddTitle
            // 
            btnAddTitle.BackColor = Color.Gray;
            btnAddTitle.Font = new Font("Courier New", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddTitle.ForeColor = Color.Cyan;
            btnAddTitle.Location = new Point(487, 189);
            btnAddTitle.Name = "btnAddTitle";
            btnAddTitle.Size = new Size(261, 68);
            btnAddTitle.TabIndex = 9;
            btnAddTitle.Text = "Add Vendor";
            btnAddTitle.UseVisualStyleBackColor = false;
            btnAddTitle.Click += btnAddTitle_Click;
            // 
            // Vendors
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAddTitle);
            Controls.Add(txtName);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(Back);
            Controls.Add(label1);
            Name = "Vendors";
            Text = "Vendors";
            Load += Vendors_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button Back;
        private DataGridView dataGridView1;
        private Label label2;
        private TextBox txtName;
        private Button btnAddTitle;
    }
}