﻿namespace $safeprojectname$
{
    partial class Media
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Back = new Button();
            dataGridView1 = new DataGridView();
            txtName = new TextBox();
            btnAddTitle = new Button();
            label2 = new Label();
            label3 = new Label();
            txtType = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Cyan;
            label1.Location = new Point(261, 31);
            label1.Name = "label1";
            label1.Size = new Size(227, 39);
            label1.TabIndex = 0;
            label1.Text = "Media Data";
            // 
            // Back
            // 
            Back.BackColor = Color.Gray;
            Back.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Back.ForeColor = Color.Cyan;
            Back.Location = new Point(12, 402);
            Back.Name = "Back";
            Back.Size = new Size(105, 36);
            Back.TabIndex = 2;
            Back.Text = "Back";
            Back.UseVisualStyleBackColor = false;
            Back.Click += Back_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(79, 90);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(409, 266);
            dataGridView1.TabIndex = 3;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtName
            // 
            txtName.BackColor = Color.Gray;
            txtName.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.ForeColor = Color.Cyan;
            txtName.Location = new Point(505, 131);
            txtName.Name = "txtName";
            txtName.Size = new Size(261, 26);
            txtName.TabIndex = 4;
            // 
            // btnAddTitle
            // 
            btnAddTitle.BackColor = Color.Gray;
            btnAddTitle.Font = new Font("Courier New", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddTitle.ForeColor = Color.Cyan;
            btnAddTitle.Location = new Point(505, 288);
            btnAddTitle.Name = "btnAddTitle";
            btnAddTitle.Size = new Size(261, 68);
            btnAddTitle.TabIndex = 5;
            btnAddTitle.Text = "Add Title";
            btnAddTitle.UseVisualStyleBackColor = false;
            btnAddTitle.Click += btnAddTitle_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Courier New", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Cyan;
            label2.Location = new Point(505, 90);
            label2.Name = "label2";
            label2.Size = new Size(264, 27);
            label2.TabIndex = 6;
            label2.Text = "Input Media Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Courier New", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Cyan;
            label3.Location = new Point(505, 185);
            label3.Name = "label3";
            label3.Size = new Size(250, 27);
            label3.TabIndex = 8;
            label3.Text = "Input Media Type:";
            // 
            // txtType
            // 
            txtType.BackColor = Color.Gray;
            txtType.Font = new Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtType.ForeColor = Color.Cyan;
            txtType.Location = new Point(505, 231);
            txtType.Name = "txtType";
            txtType.Size = new Size(261, 26);
            txtType.TabIndex = 9;
            // 
            // Media
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(txtType);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnAddTitle);
            Controls.Add(txtName);
            Controls.Add(dataGridView1);
            Controls.Add(Back);
            Controls.Add(label1);
            Name = "Media";
            Text = "Add Type";
            Load += Media_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button Back;
        private DataGridView dataGridView1;
        private TextBox txtName;
        private Button btnAddTitle;
        private Label label2;
        private Label label3;
        private TextBox txtType;
    }
}